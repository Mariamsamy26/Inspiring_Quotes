---
name: Report Downtime
about: Use this issue template if the API is down or not responding
title: API is down
labels: [':warning: API is down', 'status: reported']
assignees: '@lukePeavey'
---

