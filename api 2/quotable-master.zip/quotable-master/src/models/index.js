import Quotes from './Quotes.js'
import Authors from './Authors.js'
import Tags from './Tags.js'

export default { Quotes, Authors, Tags }
