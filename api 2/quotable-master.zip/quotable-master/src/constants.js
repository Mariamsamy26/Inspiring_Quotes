export const MAX_LIMIT = 150
export const DEFAULT_LIMIT = 20
export const MAX_RANDOM_COUNT = 50
